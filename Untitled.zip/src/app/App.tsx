import { Navbar } from './components/Navbar.jsx';
import { HeroSection } from './components/HeroSection.jsx';
import { AboutSection } from './components/AboutSection.jsx';
import { MenuSection } from './components/MenuSection.jsx';

export default function App() {
  return (
    <div className="min-h-screen bg-[#1C4D19]">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <MenuSection />
    </div>
  );
}